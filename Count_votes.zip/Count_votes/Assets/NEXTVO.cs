using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NEXTVO : MonoBehaviour
{

 public Vectors NETTV;
 //public GameObject Field;
  public GameObject Field2;
    public GameObject Silders;
    public GameObject Silderv;
    public GameObject Ebutto;
//public GameObject Hide;
// public GameObject Hide2;
 bool Mee = false;
public AudioSource No;
   public void NEXTVEC()
    {
        if(NETTV.VECINDEX < 24){
        NETTV.VECINDEX++;
        }
        else if(Mee == false){
            //Field.SetActive(true);
            Field2.SetActive(true);
            Silders.SetActive(true);
            Silderv.SetActive(true);
            Ebutto.SetActive(true);
            //Hide.SetActive(false);
            //Hide2.SetActive(false);
            Mee = true;
            
        }
        else{
        //Hide.SetActive(false);
         No.Play(0);
         transform.Translate(500, 0, 0, 0);
        }
    }


}
