using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
public class Sliders : MonoBehaviour
{

    public Slider slider;
    public TextMeshProUGUI sliderText;
    public int SValue;

    void Update()
    {
        SValue = (int)slider.value;
       
       
        sliderText.text = slider.value.ToString();
    }
}