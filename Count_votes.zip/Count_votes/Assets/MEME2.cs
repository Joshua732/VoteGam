using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MEME2 : MonoBehaviour
{
    public AudioSource Noo;
    // Start is called before the first frame update
    public void Trans()
    {
        Noo.Play(1);
        transform.Translate(500, 0, 0, 0);
    }

}
