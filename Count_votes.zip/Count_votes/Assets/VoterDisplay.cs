using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class VoterDisplay : MonoBehaviour
{
    // Start is called before the first frame update


   public string TTTT = "TEST";

  public TMP_Text counterText;
 public string OUTPUT;
 public Vectors VOTAS;
 void Start(){
 
 }
    void Update()
   {
      //counterText.text = counter.ToString();
    OUTPUT = VOTAS.Votes[VOTAS.VECINDEX];
      //counterText.text = Vectors.TOTALVOTES.ToString();
    counterText.text = OUTPUT;
   }
}
