using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Threading;
public class winloss : MonoBehaviour
{
public GameObject win;
public GameObject loss;

public GameObject Leav;

int valueH;
 public Vectors AWN;
public Sliders SID;
 public void ReadIN(){
    //ENTER = Input;
    //int NumC = int.Parse(ENTER); 
valueH = SID.SValue;
    if(valueH == AWN.FakeVotes){
        win.SetActive(true);
        loss.SetActive(false);
        Leav.SetActive(true);
         Debug.Log("WIN :" + AWN.FakeVotes);
         //Thread.Sleep(5000);
          //SceneManager.LoadScene("Menu");
    }
    else if (valueH != AWN.FakeVotes){
        win.SetActive(false);
        loss.SetActive(true);
         Debug.Log("Loss :" + AWN.FakeVotes);
         //Thread.Sleep(5000);
         Leav.SetActive(true);
         // SceneManager.LoadScene("Menu");
    }
 }
}
