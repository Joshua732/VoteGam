using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Vectors : MonoBehaviour
{
public List<string> Names = new List<string>();
public List<string> Votes = new List<string>();
public int FakeVotes;
public int TOTALVOTES;
public int VECINDEX;

    // Start is called before the first frame update
    void Start()
    {
        VECINDEX = 0;
        Names.Add("Clary Lee");
        Names.Add("Hilda Lee");
        Names.Add("Tolay Ton");
        Names.Add("Loa Ton");
        Names.Add("Toa Long");
        Names.Add("Herna Long");
        Names.Add("Clary Smith");
        Names.Add("Herny Smith");
        Names.Add("Lona Cloth");
        Names.Add("Lone Cloth");
        Names.Add("Zack Blant");
        Names.Add("Qawn Blant");
        Names.Add("Latly Kine");
        Names.Add("Loancy Kine");
        Names.Add("Kart Tyne");
        Names.Add("Kent Tyne");
        Names.Add("Persy Tyne");
        Names.Add("Dylan Tyne");
        Names.Add("Lizon Rucker");
        Names.Add("Larry Rucker");
        Names.Add("Tina Booker");
        Names.Add("Breen Booker");
        Names.Add("Obama Booker");
        Names.Add("Trump Booker");
        Names.Add("Earl Brock");
        Names.Add("Carly Brock");
        Names.Add("Hilda Tilda");
        Names.Add("Barry Tilda");
        Names.Add("Parry Tilda");
        Names.Add("Karl Tilda");
        Names.Add("Warrio Stin");
        Names.Add("Mark Stin");
        Names.Add("Monta Lin");
        Names.Add("Pent Lin");
        Names.Add("Hilda Brik");
        Names.Add("Hilda Brik");
        Names.Add("Hilda Brik");
        Names.Add("Hilda Brik");
        Names.Add("Jack Linda");
        Names.Add("Windy Linda");
        Names.Add("Peter Linda");
        Names.Add("Marco Pint");
        Names.Add("Toney Pint");
        Names.Add("Tend D");
        Names.Add("Lelda D");
        Names.Add("Hilda Gane");
        Names.Add("Hilda Gane");
        Names.Add("Hilda Gane");
        Names.Add("Hilda Gane");
        Names.Add("Larry Darnte");
        Names.Add("Poney Darnte");
        Names.Add("Unte Darnte");
        Names.Add("Iden Barn");
        Names.Add("Mona Barn");
        Names.Add("Dee Barn");
        Names.Add("Mat Warry");
        Names.Add("Text Warry");
        Names.Add("Deset Warry");
        Names.Add("Opet Mlat");
        Names.Add("Darry Mlat");




    // foreach (var label in Names) Debug.Log("NameOutput :" + label);

    int RAN = Random.Range(1, 6);
    for (int i = 0; i < 25; i++)
    {
        RAN = Random.Range(0, 60);
        Votes.Add(Names[RAN]);
        Debug.Log("Number :" + RAN);
    }
   //foreach (var OUTLIST in Votes) Debug.Log("NameOutput :" + OUTLIST);

List<string> VotesCopy = Votes.ToList();
VotesCopy = VotesCopy.Distinct().ToList();
FakeVotes = Votes.Count - VotesCopy.Count;
TOTALVOTES = 25;
Debug.Log("DupeVotes :" + FakeVotes);
    }
    

    // Update is called once per frame

}
